.. MMUD documentation master file, created by
   sphinx-quickstart on Wed Apr 17 14:49:21 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MMUD's documentation!
================================

**MUD** is a simple multi-player adventure game with elements of PVE.
Player can create and attack monsters, move around the field and communicate
with other players.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   server_documentation

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
