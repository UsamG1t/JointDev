"""Start server."""
from . import start
import asyncio

start()